/**
 * 
 */
package pobj.motx.tme3.csp;

import java.util.List;

import pobj.motx.tme2.GrillePotentiel;

/**
 * @author Mohamed M. THIAM
 *
 */
public class DicoVariable implements IVariable {
	//l'indice de l'emplacement du mot correspondant
	private int indice;
	
	//une référence à une GrillePotentiel
	private GrillePotentiel gPot;
	
	public DicoVariable(int indice, GrillePotentiel gPot) {
		this.indice = indice;
		this.gPot = gPot;
	}

	@Override
	public List<String> getDomain() {
		return gPot.getMotsPot().get(indice).getAllWords();
	}

	@Override
	public String toString() {
		return gPot.toString();
	}
	
	/**
	 * Getter sur l'attribut GrillePotentiel
	 * @return la GrillePotentiel
	 */
	public GrillePotentiel getgPot() {
		return gPot;
	}
	
	public int getIndice() {
		return indice;
	}
}












