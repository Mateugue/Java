/**
 * 
 */
package pobj.motx.tme3.csp;

import java.util.List;

/**
 * @author Mohamed M. THIAM
 *
 */
public interface IVariable {
	
	/**
	 * L'ensemble des valeurs que peut prendre une IVariable. Comme il s'agit de mot ce sera une liste
	 * 	de String
	 * @return le domaine est donc l'ensemble des valeurs(mots) que peuvent prendre une variable donnée
	 */
	List<String> getDomain();

}
