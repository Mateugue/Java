/**
 * 
 */
package pobj.motx.tme3.csp;

import java.util.List;

/**
 * @author Mohamed M. THIAM
 *
 */
public interface ICSP {
	
	/**
	 * Permet d'accéder aux variables du problème
	 * @return la liste des variables du problème
	 */
	List<IVariable> getVars();
	
	/**
	 * Permet de tester si un problème est encore satisfiable, et donc !(isDead)
	 * @return un booléen pour savoir si un problème est encore satisfiable
	 */
	boolean isConsistent();
	
	/**
	 * Permet d'affecter une des variables du problème
	 * @param vi est la variable
	 * @param val est la valeur à fixer
	 * @return un nouveau problème ICSP de même nature que le précédent mais avec une var en moins, puisqu'elle
	 * 	a été fixée
	 */
	ICSP assign(IVariable vi, String val);
}
