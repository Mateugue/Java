/**
 * 
 */
package pobj.motx.tme3.csp;

import java.util.ArrayList;
import java.util.List;

import pobj.motx.tme1.Emplacement;
import pobj.motx.tme2.GrillePotentiel;

/**
 * @author Mohamed M. THIAM
 *
 */
public class MotX implements ICSP {
	//une liste de DicoVariable
	private List<DicoVariable> listDicoV;
	
	//une GrillePotentiel
	private GrillePotentiel gPot;
	
	
	/**
	 * @param gPot une GrillePotentiel
	 * 
	 */
	public MotX(GrillePotentiel gPot) {
		this.gPot = gPot;
		listDicoV = new ArrayList<>();
		int nbEmpl = gPot.getGplaces().getPlaces().size();
		List<Emplacement> listEmpl = gPot.getGplaces().getPlaces();
		Emplacement empl;
		for(int i = 0; i < nbEmpl; i++) {
			empl = listEmpl.get(i);
			if(empl.hasCaseVide()) {
				DicoVariable dicoV = new DicoVariable(i, gPot);
				listDicoV.add(dicoV);
			}
		}
	}

	@Override
	public List<IVariable> getVars() {
		List<IVariable> listVar = new ArrayList<>();
		listVar.addAll(listDicoV);
		/*for(DicoVariable dicoV : listDicoV) {
			listVar.add(dicoV);
		}*/
		return listVar;
	}

	@Override
	public boolean isConsistent() {
		return !(gPot.isDead());
	}

	@Override
	public ICSP assign(IVariable vi, String val) {
		if(vi instanceof DicoVariable) {
			DicoVariable dicoV = (DicoVariable) vi;
			int i = dicoV.getIndice();
			GrillePotentiel gPot2 = dicoV.getgPot().fixer(i, val);
			MotX mx = new MotX(gPot2);
			return mx;
		}
		return null;
	}
	

}
