/**
 * 
 */
package pobj.motx.tme1;

/**
 * @author Mohamed M; THIAM
 * Représente une case de la grille de mot croisé
 */
public class Case {
	/**
	 * Ses coordonnées dans la grille et sa contenance qui peut être une lettre, vide ou aucune des deux
	 */ 
	private int lig;
	private int col;
	private char c;
	
	public Case(int lig, int col, char c) {
		this.lig = lig;
		this.col = col;
		this.c = c;
	}
	
	/**
	 * Récupère ce qui se trouve dans la case
	 * @return la lettre qui se trouve dans la case
	 */
	public char getChar() {
		return c;
	}
	
	/**
	 * Récupère la colonne de la case concernée
	 * @return le numéro de colonne
	 */
	public int getCol() {
		return col;
	}
	
	/**
	 * Récupère la ligne de la case concernée
	 * @return le numéro de ligne
	 */
	public int getLig() {
		return lig;
	}
	
	/**
	 * Permet de mettre une lettre dans la case
	 * @param c est donc le caractère à mettre
	 */
	public void setChar(char c) {
		this.c = c;
	}
	
	/**
	 * Vérifie si la case est vide et donc une possibilité qu'une lettre y soit inscrite
	 * @return le booléen pour
	 */
	public boolean isVide() {
		if(this.c == ' ') {
			return true;
		}
		return false;
	}
	
	/**
	 * Vérifie si la case est pleine et donc une impossibilité d'y inscrire une lettre
	 * @return le booléen pour
	 */
	public boolean isPleine() {
		if(this.c == '*') {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean equals(Object obj) {
//		if(thiss == obj) return true;
		if(obj== null) return false;
		if(getClass() != obj.getClass()) return false;
		Case case1 = (Case) obj;
		if(this.lig != case1.lig) return false;
		if(this.col != case1.col) return false;
		if(this.c != case1.c) return false;
    	return true;
    }
}