/**
 * 
 */
package pobj.motx.tme1;

/**
 * @author Mohamed M. THIAM
 * Représentation de la grille de mot croisé
 */
public class Grille {
	/**
	 * Matrice de Case pour représenter une grille de mot croisé
	 */
	private Case[][] grille;
	
	/**
	 * Constructeur d'une grille avec ses dimensions
	 * @param ligne est le nombre de ligne qui composent la grille
	 * @param colonne est le nombre de colonne qui composent la grille
	 */
	public Grille(int ligne, int colonne) {
		grille = new Case[ligne][colonne];
		for(int i = 0; i < ligne; i++) {
			for(int j = 0; j < colonne; j++) {
				grille[i][j] = new Case(i, j, ' ');
			} 
		}
	}
	
	/**
	 * Indique la case aux positions indiquée
	 * @param lig est la ligne de la case voulue
	 * @param col est la colonne de la case voulue
	 * @return la case de la grille aux positions indiquées
	 */
	public Case getCase(int lig, int col) {
		return grille[lig][col];
	}
	
	/**
	 * Affiche de manière optimale la grille
	 */
	public String toString() {
		return GrilleLoader.serialize(this, false);
	}
	
	/**
	 * 
	 * @return Le nombre de ligne de la grille
	 */
	public int nbLig() {
		return grille.length;
	}

	/**
	 * 
	 * @return Le nombre de colonne de la grille
	 */
	public int nbCol() {
		return grille[0].length;
	}
	
	/**
	 * Place une case aux positions indiquées
	 * @param c est la case à placer
	 * @param lig est la ligne concernée
	 * @param col est la colonne concernée
	 */
	public void setCase(Case c, int lig, int col) {
		Case gc = grille[lig][col];
		gc.setChar(c.getChar());
	}
	
	/**
	 * Copie la grille
	 * @return une copie physique de la grille
	 */
	public Grille copy() {
		int col = nbCol();
		int lig = nbLig();
		Grille g = new Grille(lig, col);
		for(int i = 0; i < lig; i++) {
			for(int j = 0; j < col; j++) {
				g.setCase(getCase(i, j), i, j); 
			}
		}
		return g;
	}
}
