/**
 * 
 */
package pobj.motx.tme1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohamed M. THIAM
 * Une liste de cases contigues où un mot peut y être placé
 */
public class Emplacement {
	private List<Case> lettres = new ArrayList<>();
	
	
	/**
	 * Méthode standard qui indique ce qui se trouve dans l'emplacement tel
	 *  @return la chaine de caractère qui s'y trouve 
	 */
	public String toString() {
		String s = "";
		for(Case c : lettres) {
			s += c.getChar(); 
		}
		return s;
	}
	
	/**
	 * Indique le nombre de case de l'emplacement
	 * @return la taille de l'emplacement
	 */
	public int size() {
		return lettres.size();
	}
	
	/**
	 * Accesseur sur la liste de case
	 * @return l'emplacement avec les cases qui s'y trouvent
	 */
	public List<Case> getLettres() {
		return lettres;
	}
	
	/**
	 * Ajoute une case à l'emplacement
	 * @param c est la case qu'on ajoute
	 */
	public void ajouteCase(Case c) {
		lettres.add(c);
	}
	
	/**
	 * Retourne la case à la position i
	 * @param i la position de la case à retourner
	 * @return la case à la position i
	 */
	public Case getCase(int i) {
		return lettres.get(i);
	}
	
	/**
	 * Cherche dans la liste de Case, dès qu'une case est vide, renvoie true
	 * @return true si une case de l'emplacement est vide
	 */
	public boolean hasCaseVide() {
		for(Case c : lettres) {
			if(c.isVide()) {
				return true;
			}
		}
		return false;
	}
}
