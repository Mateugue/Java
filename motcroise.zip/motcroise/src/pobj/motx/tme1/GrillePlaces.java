/**
 * 
 */
package pobj.motx.tme1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohamed M. THIAM
 * Permet de calculer les emplacements disponibles dans la grille
 */
public class GrillePlaces {
	//la grille concernée
	private Grille grille;
	
	//la liste des emplacements de la grille
	private List<Emplacement> places;
	
	//le nombre de mots horizontaux
	private int nbHorz;
	
	public GrillePlaces(Grille grille) {
		this.grille = grille;
		places = new ArrayList<>();
		int ligne = grille.nbLig();
		int colonne = grille.nbCol();
		List<Case> empLig, empCol;
		
		for(int i = 0; i < ligne; i++) {
			empLig = getLig(i);
			cherchePlaces(empLig);
		}
		nbHorz = places.size();
		for(int j = 0; j < colonne; j++) {
			empCol = getCol(j);
			cherchePlaces(empCol); 
			
		}
	}
	
	/**
	 * Donne la liste des emplacements de la grille
	 * @return la liste des emplacements de la grille
	 */
	public List<Emplacement> getPlaces() {
		return places;
	}
	
	/**
	 * Accesseur sur le nombre de mots horizontaux
	 * @return le nombre de mots horizontaux
	 */
	public int getNbHorizontal() {
		return nbHorz;
	}
	
	/**
	 * Doit afficher les emlacements de mots détectés de façon lisible
	 */
	public String toString() {
		return grille.toString();
	}
	
	/**
	 * Donne une liste de cases qui se trouvent sur une même ligne 
	 * @param lig est la ligne concernée
	 * @return la liste des cases de cette ligne
	 */
	private List<Case> getLig(int lig){
		List<Case> liste = new ArrayList<>();
		for(int j = 0; j < grille.nbCol(); j++) {
			liste.add(grille.getCase(lig, j));
		}
		return liste;
	}
	
	/**
	 * Donne une liste de cases qui se trouvent sur une même colonne
	 * @param col est la colonne concernée
	 * @return la liste des cases de la colonne indiquée
	 */
	private List<Case> getCol(int col){
		List<Case> liste = new ArrayList<>();
		for(int i = 0; i < grille.nbLig(); i++) {
			liste.add(grille.getCase(i, col));
		}
		return liste;
	}
	
	/**
	 * Méthode qui cherche les cases contigues qui forment donc un emplacement sur une liste donnée
	 * @param cases est la liste de cases où chercher
	 */
	private void cherchePlaces(List<Case> cases) {
		Emplacement emp = new Emplacement();
		for(Case c : cases) {
			if(!(c.isPleine())) {
				emp.ajouteCase(c);
			}else {
				if(emp.size() >= 2) {
					places.add(emp);
				}
				emp = new Emplacement();
			}
		}
		if(emp.size() >= 2) {
			places.add(emp);
		}
	}
	
	/**
	 * 
	 * @param m
	 * @param soluce
	 * @return
	 */
	public GrillePlaces fixer(int m, String soluce) {
		Grille gr = grille.copy();
		GrillePlaces gp = new GrillePlaces(gr);
		char c;
		Emplacement empl = gp.getPlaces().get(m);
		for(int i = 0; i < empl.size(); i++) {
			c = soluce.charAt(i);
			empl.getCase(i).setChar(c);
		}
		
		return gp;
	}
}

