/**
 * 
 */
package pobj.motx.tme2;


/**
 * @author Mohamed M. THIAM
 *
 */
public class CroixContrainte implements IContrainte {
	//pour stocker les indices des contraintes
	private int m1, c1, m2, c2;

	/**
	 * 
	 * @param m1
	 * @param c1
	 * @param m2
	 * @param c2
	 */
	public CroixContrainte(int m1, int c1, int m2, int c2) {
		this.m1 = m1;
		this.c1 = c1;
		this.m2 = m2;
		this.c2 = c2;
	}

	
	@Override
	public int reduce(GrillePotentiel grillePot) {
		int cpt = 0;
		EnsembleLettres l1 = grillePot.get(m1).getEnsLettresFromDico(c1);
		EnsembleLettres l2 = grillePot.get(m2).getEnsLettresFromDico(c2);

		EnsembleLettres s = l1.copy();
		//réalisation de l'intersection 
		s.getList().retainAll(l2.getList());
		
		if(l1.size() > s.size()) {
			cpt += grillePot.get(m1).filtreLettreInMot(s, c1);
		}
		if(l2.size() > s.size()) {
			cpt += grillePot.get(m2).filtreLettreInMot(s, c2);
		}
		return cpt;
	}
	
	@Override
	 public boolean equals(Object obj) {
		if(this == obj) return true;
		if(obj== null) return false;
		if(getClass() != obj.getClass()) return false;
		CroixContrainte contrainte = (CroixContrainte) obj;
       if(contrainte.m1 != m1) return false;
       if(contrainte.c1 != c1) return false;
       if(contrainte.m2 != m2) return false;
       if(contrainte.c2 != c2) return false;

       return true;
   }

}
