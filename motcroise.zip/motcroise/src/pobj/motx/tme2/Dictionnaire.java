package pobj.motx.tme2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;


/**
 * Un ensemble de mots.
 *
 */
public class Dictionnaire {

	// stockage des mots
	private List<String> mots = new ArrayList<>();

	/**
	 * Ajoute un mot au Dictionnaire, en dernière position.
	 * @param mot à ajouter, il sera stocké en minuscules (lowerCase)
	 */
	public void add(String mot) {
		mots.add(mot.toLowerCase());
	}

	/**
	 * Taille du dictionnaire, c'est à dire nombre de mots qu'il contient.
	 * @return la taille
	 */
	public int size() {
		return mots.size();
	}
	
	/**
	 * Accès au i-eme mot du dictionnaire.
	 * @param i l'index du mot recherché, compris entre 0 et size-1.
	 * @return le mot à cet index
	 */
	public String get(int i) {
		return mots.get(i);
	}

	/**
	 * Rend une copie de ce Dictionnaire.
	 * @return une copie identique de ce Dictionnaire
	 */
	public Dictionnaire copy () {
		Dictionnaire copy = new Dictionnaire();
		copy.mots.addAll(mots);
		return copy;
	}

	/**
	 * Retire les mots qui ne font pas exactement "len" caractères de long.
	 * Attention cette opération modifie le Dictionnaire, utiliser copy() avant de filtrer pour ne pas perdre d'information.
	 * @param len la longueur voulue 
	 * @return le nombre de mots supprimés
	 */
	public int filtreLongueur(int len) {
		List<String> cible = new ArrayList<>();
		int cpt=0;
		for (String mot : mots) {
			if (mot.length() == len)
				cible.add(mot);
			else
				cpt++;
		}
		mots = cible;
		return cpt;
	}

	
	@Override
	public String toString() {
		if (size() == 1) {
			return mots.get(0);
		} else {
			return "Dico size =" + size();
		}
	}
	
	/**
	 * Permet de charger une liste de mots depuis un fichier texte pour en faire un dictionnaire de mots
	 * @param path est le chemin du fichier qui contient le texte des mots
	 * @return un nouveau dictionnaire
	 */
	public static Dictionnaire loadDictionnaire(String path) {
		Dictionnaire dico = new Dictionnaire();
		List<String> liste = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader(path))) {
			for(String line = br.readLine(); line != null ; line = br.readLine()) {
				liste.add(line);
			}
			dico.setMots(liste);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dico;
	}
	
	/**
	 * Permet de rajouter une liste de mots au dictionnaire
	 * @param liste contient une liste de mots
	 */
	private void setMots(List<String> liste) {
		mots.addAll(liste);
		
	}
	
	/**
	 * Filtre la liste de mots du dictionnaire en attribut pour ne garder que les mots dont le i-eme 
	 * caractère est le paramètre c
	 * @param c le caractère voulu
	 * @param i la position du caractère voulu
	 * @return le nombre de mots qui n'ont pas le caractère c à la position i
	 */
	public int filtreParLettre(char c, int i) {
		List<String> cible = new ArrayList<>();
		int cpt = 0;
		for (String mot : mots) {
			if(mot.charAt(i) == c) {
				if(!(cible.contains(mot))){
					cible.add(mot);
				}
			}
			else
				cpt++;
		}
		mots = cible;
		return cpt;
	}
	
	/**
	 * Renvoie la liste des mots du dictionnaire
	 * @return la liste des mots du dictionnaire
	 */
	public List<String> getMots() {
		return mots;
	}
	
	/**
	 * Permet d'avoir un ensemble de lettres des i-eme caractère des mots du dictionnaire
	 * @param i la position recherchée
	 * @return un nouvel EnsembleLettres aveec les lettres de ieme position de chaque mot du dictionnaire
	 */
	public EnsembleLettres getEnsLettresFromDico(int i) {
		EnsembleLettres ens = new EnsembleLettres();
		for(String mot : mots) {
			ens.add(mot.charAt(i));
		}
		return ens;
	}
	
	/**
	 * Filtre les mots qui ont à la position i une lettre qui se trouve dans l'ensemble lettres
	 * @param ens contient l'ensemble des lettres
	 * @param i la position du mot où on cherche
	 * @return le nombre de mot filtrés, qui n'ont pas à la position i une lettre qui se trouve\ 
	 dans l'ensemble
	 */
	public int filtreLettreInMot(EnsembleLettres ens, int i) {
		int nb = 0;
		List<String> cible = new ArrayList<String>();
		for (String mot : mots) {
			if (ens.contains(mot.charAt(i)))
				cible.add(mot);
			else
				nb++;
		}
		mots = cible;
		return nb;
	}
	
	/**
	 * Donne l'ensemble des mots qui sont dans le dictionnaire complet
	 * @return la liste complètye des mots qui se trouvent dans le dictionnaire complet
	 */
	public List<String> getAllWords() {
		return mots;
		
	}
}
