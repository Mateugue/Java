/**
 * 
 */
package pobj.motx.tme2;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohamed M. THIAM
 * Représente un ensemble de lettres
 */
public class EnsembleLettres {
	//contiendra les lettres
	private List<Character> listeLettres;
	
	/**
	 * Un constructeur qui initialise l'attribut depuis une liste de caractères
	 * @param list est utilisée pour initialisée l'attribut
	 */
	public EnsembleLettres(List<Character> list) {
		listeLettres = list;
	}
	
	/**
	 * Initialisation de l'attribut vide
	 */
	public EnsembleLettres() {
		listeLettres = new ArrayList<>();
	}
	
	/**
	 * Ajoute le caractère dans la liste
	 * @param c est le caractère ajouté
	 */
	public void add(char c) {
		if(!(listeLettres.contains(c))) {
			listeLettres.add(c);
		}
	}
	
	/**
	 * Donne la taille de la liste
	 * @return le nombre de lettres de la liste
	 */
	public int size() {
		return listeLettres.size();
	}
	
	/**
	 * Fait une intersection de l'EnsembleLettres appelant avec celui en paramètre
	 * @param l2 paramètre qui est utilisé pour faire l'intersection
	 * @return un nouvel EnsembleLettres qui contiendra l'intersection des 2 listes de caractère
	 */
	public EnsembleLettres intersection(EnsembleLettres l2) {
		List<Character> copy = listeLettres;
		copy.retainAll(l2.getList());
		return new EnsembleLettres(copy);
	}
	
	/**
	 * Fait une copie de liste de caractère de l'instance EnsembleLettres appelant
	 * @return un nouvel EnsembleLettres contenant les mêmes caractères que celui de l'appelant
	 */
	public EnsembleLettres copy() {
		EnsembleLettres cpy = new EnsembleLettres();
		for(Character l : listeLettres){
            cpy.getList().add(l);
        }
		return cpy;
	}
	
	/**
	 * Donne la liste de caractères
	 * @return la liste de caractères
	 */
	public List<Character> getList() {
		return listeLettres;
	}
	
	/**
	 * Permet de savoir si un caractère se trouve dans la liste
	 * @param c le caractère qu'on veut savoir s'il est dans la liste
	 * @return un boolean qui nous dit s'il est dedans ou pas
	 */
	public boolean contains(char c) {
		return listeLettres.contains(c);
	}
}
