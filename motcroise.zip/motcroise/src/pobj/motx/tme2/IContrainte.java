/**
 * 
 */
package pobj.motx.tme2;

/**
 * @author Mohamed M. THIAM
 * Etablis les contraintes liées aux mots déja placés
 */
public interface IContrainte {
	
	/**
	 * Modifie la grille passée en 	argument en filtrant les mots selon les contraintes de 
	 * croisement
	 * @param grille
	 * @return le nombre total de mots filtés par son action
	 */
	public int reduce(GrillePotentiel grille);
}
