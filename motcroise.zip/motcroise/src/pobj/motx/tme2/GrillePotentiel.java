/**
 * 
 */
package pobj.motx.tme2;

import java.util.ArrayList;
import java.util.List;

import pobj.motx.tme1.Case;
import pobj.motx.tme1.Emplacement;
import pobj.motx.tme1.GrillePlaces;

/**
 * @author Mohamed M. THIAM
 *
 */
public class GrillePotentiel {
	private GrillePlaces gplaces;
	private Dictionnaire dico;
	private List<Dictionnaire> motsPot;
	private List<IContrainte> contraintes;
	
	/**
	 * Constructeur de GrillePotentiel en initialisant pour chaque emplacement sa liste de mots potentiel
	 * 	qui est connue avec la taille des mots et de l'emplacement
	 * Détection des contraintes qui se trouve sur la grille en croisant chacune des cases des mots 
	 * 	horizontaux avec celles des mots verticaux. Ces contraintes sont ajoutées dans la liste créée pour.
	 * A la fin des initialisation et détection, ces contraintes sont propagées
	 * @param gplaces
	 * @param dicoComplet
	 */
	public GrillePotentiel(GrillePlaces gplaces, Dictionnaire dicoComplet) {
		this.gplaces = gplaces;
		this.dico = dicoComplet;
		motsPot = new ArrayList<>();
		contraintes = new ArrayList<>();
		
		List<Emplacement> places = this.gplaces.getPlaces();
		Dictionnaire d = new Dictionnaire();
		Case c;
		for(Emplacement emp : places) {
			d = dico.copy();
			d.filtreLongueur(emp.size());
			for(int i = 0; i < emp.getLettres().size(); i++) {
				c = emp.getLettres().get(i);
				if(!c.isVide() && !c.isPleine()) {
					d.filtreParLettre(c.getChar(), i);
				}
			}
			if(!motsPot.contains(d)) {
				motsPot.add(d);
			}
			d = new Dictionnaire();
		}
		Emplacement motHorz;
		Emplacement motVerti;
		int sizeGrillePlace = gplaces.getPlaces().size();
		int nbMotHorz = gplaces.getNbHorizontal();
		
		Case caseH;
		Case caseV;
		CroixContrainte contrainte;
		
		//boucle sur les emplacements horizontaux et verticaux
		for(int m1 = 0; m1 < nbMotHorz; m1++) {
			motHorz = gplaces.getPlaces().get(m1);
			for(int m2 = nbMotHorz; m2 < sizeGrillePlace; m2++) {
				motVerti = gplaces.getPlaces().get(m2);
				
				//boucle sur les cases des emplaements verticaux et horizontaux
				for(int c1 = 0; c1 < motHorz.size(); c1++) {
					caseH = motHorz.getLettres().get(c1);
					for(int c2 = 0; c2 < motVerti.size(); c2++) {
						caseV = motVerti.getLettres().get(c2);
						
						if((caseH.equals(caseV)) && caseH.isVide() && caseV.isVide()) {
							/*il ya croisement et donc m1 est le mot H et c1 est sa case et 
							 *reciproquement m2 est V et c2 est sa case
							*/
							contrainte = new CroixContrainte(m1, c1, m2, c2);
							if(!contraintes.contains(contrainte)) {
								contrainte.reduce(this);
								contraintes.add(contrainte);
							}
						}
					}
				}
			}
		}
		propage();
	}
	
	/**
	 * Permet de savoir si le mot croisé est toujours résolvable en regardant la taille de chacun
	 *  des dictionnaires potentiels des emplacments
	 * @return un booléen qui nous permet de le savoir
	 */
	public boolean isDead() {
		for(Dictionnaire d : motsPot) {
			if(d.size() == 0) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Donne la liste des mots potentiels pour chacun des emplacements de la grille
	 * @return une liste de dictionnaire
	 */
	public List<Dictionnaire> getMotsPot() {
		return motsPot;
	}
	
	/**
	 * Permet de positionner un mot sur un emplacement donné
	 * @param m la postion de l'emplacement où on veut placer les lettres du mot
	 * @param soluce le mot à placer
	 * @return un nouveau GrillePotentiel dans lequel l'emplacement m est positionné avec le mot soluce 
	 */
	public GrillePotentiel fixer(int m, String soluce) {
		return new GrillePotentiel(gplaces.fixer(m, soluce), dico);
	}
	
	/**
	 * Retourne l'attribut grillePlaces
	 * @return l'attribut grillePlaces
	 */
	public GrillePlaces getGplaces() {
		return gplaces;
	}
	
	/**
	 * Renvoie la liste des contraintes détectées à la construction de ce GrillePotentiel
	 * @return la liste des contraintes détectées à la construction de ce GrillePotentiel
	 */
	public List<IContrainte> getContraintes() {
		return contraintes;
	}
	
	/**
	 * Donne le dictionnaire potentiel de l'emplacement i
	 * @param i la position de l'emplacement
	 * @return le dictionnaire potentiel de l'emplacement i
	 */
	public Dictionnaire get(int i) {
		return motsPot.get(i);
	}
	
	/**
	 * Permet de propager les contraintes détectées à la construction. 
	 * Permet aussi de savoir s'il est toujours possibles de résoudre le mot croisé (isDead) ou bien de 
	 * 	savoir si nous avons atteint la stabilité au quel cas, la réduction n'a plus d'effet
	 * @return
	 */
	private boolean propage() {
		int nb;
		while(true) {
			nb = 0;
			for(IContrainte contrainte : contraintes) {
				nb += contrainte.reduce(this);
				if(isDead()) {
					return false;
				}
			}
			if(nb == 0) {
				return true;
			}
		}
	}
	
	@Override
	public String toString() {
		return gplaces.toString();
	}
}
