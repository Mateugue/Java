/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Question4 {
	public static Expression e1() {
		Constant deux = new Constant(2);
		Constant trois = new Constant(3);
		Constant quattre = new Constant(4);
		return new Mult(new Add(deux, trois), quattre);
	}
	
	public static Expression e2() {
		Var x = new Var("x");
		Constant trois = new Constant(3);
		Constant quattre = new Constant(4);
		return new Mult(new Add(x, trois), new Add(x, quattre));
	}
	
	public static Expression e3() {
		Var x = new Var("x");
		Var y = new Var("y");
		Constant dix = new Constant(10);
		Constant huit = new Constant(-8);
		return new Mult(new Add(x, dix), new Add(y, huit));
	}
}
