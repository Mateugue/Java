/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Question13 {

	public static <T> T compose(IVisitor<T> f, IVisitor<T> 	g, Expression e) {
		return ((Expression) e.accept(g)).accept(f);
	}

}
