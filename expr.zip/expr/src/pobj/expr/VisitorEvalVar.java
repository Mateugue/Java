/**
 * 
 */
package pobj.expr;

import java.util.Map;

/**
 * Classe qui permet d'évaluer une expression contenant des variables
 * @author Mohamed M. THIAM
 *
 */
public class VisitorEvalVar extends VisitorEval {
	
	Map<String,Integer> map;
	
	public VisitorEvalVar(Map<String,Integer> map) {
		this.map = map;
	}
	
	@Override
	public Integer visit(Var v) {
		return map.get(v.getName());
	}
}
