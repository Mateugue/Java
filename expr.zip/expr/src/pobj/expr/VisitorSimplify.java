/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class VisitorSimplify implements IVisitor<Expression> {

	@Override
	public Expression visit(Constant c) {
		return new Constant(Question10.evalConstantExpression(c));
	}

	@Override
	public Expression visit(Add e) {
		if(Question10.isConstant(e)) {
			return new Constant(Question10.evalConstantExpression(e));
		}
		Expression left = e.getLeft().accept(this);
		Expression right = e.getRight().accept(this);
		if(Question10.isConstant(left)) {
			Constant l = (Constant) left;
			if(l.getValue() == 0) {
				return right;
			}
		}
		if(Question10.isConstant(right)) {
			Constant l = (Constant) right;
			if(l.getValue() == 0) {
				return left;
			}
		}
		return e;
	}

	@Override
	public Expression visit(Mult e) {
		if(Question10.isConstant(e)) {
			return new Constant(Question10.evalConstantExpression(e));
		}
		Expression left = e.getLeft().accept(this);
		Expression right = e.getRight().accept(this);
		
		if(Question10.isConstant(left)) {
			Constant l = (Constant) left;
			if(l.getValue() == 1) {
				return right;
			}
			if(l.getValue() == 0) {
				return new Constant(Question10.evalConstantExpression(l));
			}
		}
		if(Question10.isConstant(right)) {
			Constant r = (Constant) right;
			if(r.getValue() == 1) {
				return left;
			}
			if(r.getValue() == 0) {
				return new Constant(Question10.evalConstantExpression(r));
			}
		}
		return e;
	}

	@Override
	public Expression visit(Var v) {
		return v; //pas de simplification à faire
	}

}
