/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Question10 {
	// retourne vrai si e est un arbre d’expression constant
	public static boolean isConstant(Expression e) {
		VisitorConstant val = new VisitorConstant();
		return e.accept(val);
	}
	// retourne la valeur d’une expression constante 
	// signale une exception si l’expression n’est pas constante 
	public static int evalConstantExpression (Expression e) { 
		if(Question10.isConstant(e)) {
			VisitorEval val = new VisitorEval();
			return Integer.valueOf(e.accept(val));
		}
		return 0;
	}
}
