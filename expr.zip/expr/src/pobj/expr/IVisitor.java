package pobj.expr;
/**
 * 
 * @param <T>
 * Interface générique
 * 	pour les méthodes visit pour chaque classe concrète d’expression arithmétique
 */
public interface IVisitor<T> {
    T visit(Constant c);
    T visit(Add e);
    T visit(Mult e);
    T visit(Var v);
}
