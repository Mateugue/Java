package pobj.expr.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestQ1.class, TestQ2.class, TestQ3.class, TestQ4.class, TestQ5.class, TestQ6.class, TestQ7.class,
		TestQ8.class, TestQ9.class, TestQ10.class, TestQ11.class, TestQ12.class, TestQ13.class })
public class AllTests {

}
