package pobj.expr;
/**
 * Interface qui représente une expression
 * @author Mohamed M. THIAM
 *	
 */
public interface Expression {
	/**
	 * Evaluation d'une expression
	 * @throws UnsupportedOperationException
	 * @return la valeur de l'evaluation
	 */
//	public int eval();
	
	/**
	 * 
	 * @param <T>
	 * @return
	 */
	public<T> T accept(IVisitor<T> visitor);
}
