/**
 * 
 */
package pobj.expr;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Question8 {
	public static Map<String, Integer> env1() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		return map;
	}

	public static Map<String, Integer> env2() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("x", 10);
		map.put("y", 20);
		return map;
	}

	public static Map<String, Integer> env3() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("z", 9);
		return map;
	}
}
