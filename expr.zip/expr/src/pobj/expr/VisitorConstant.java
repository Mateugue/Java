/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class VisitorConstant implements IVisitor<Boolean>{

	@Override
	public Boolean visit(Constant c) {
		return true;
	}


	@Override
	public Boolean visit(Add e) {
		Expression left = e.getLeft();
		Expression right = e.getRight();
		if(left instanceof Constant && right instanceof Constant) {
			return true;
		}
		return left.accept(this) && right.accept(this);
	}

	@Override
	public Boolean visit(Mult e) {
		Expression left = e.getLeft();
		Expression right = e.getRight();
		if(left instanceof Constant && right instanceof Constant) {
			return true;
		}
		return left.accept(this) && right.accept(this);
	}

	@Override
	public Boolean visit(Var v) {
		return false;
	}
	
}
