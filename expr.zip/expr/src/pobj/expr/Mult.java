/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Mult extends BinOp  implements Expression {
	
	
	
	public Mult(Expression left, Expression right) {
		super(left, right);
	}

	@Override
	public String toString() {
		
		return getLeft().toString() + " * " + getRight().toString();
	}


/*	public int eval() {
		return getLeft().eval() + getRight().eval();
	}
*/	
	@Override
	public <T> T accept(IVisitor<T> visitor) {
		return visitor.visit(this);
	}
}
