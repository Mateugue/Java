/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class VisitorDerive implements IVisitor<Expression> {
	private Var x;
	public VisitorDerive(Var x) {
		this.x = x;
	}

	@Override
	public Expression visit(Constant c) {
		return new Constant();
	}

	@Override
	public Expression visit(Add e) {
		if(Question10.isConstant(e)) {
			return new Constant();
		}
		return new Add(e.getLeft().accept(this), e.getRight().accept(this));
	}

	@Override
	public Expression visit(Mult e) {
		if(Question10.isConstant(e)) {
			return new Constant();
		}
		Expression left = e.getLeft();
		Expression right = e.getRight();
		
		return new Add(new Mult(left, right.accept(this)), new Mult(left.accept(this), right));
	}

	@Override
	public Expression visit(Var v) {
		if(x.equals(v)) {
			return new Constant(1);
		}
		return new Constant();
	}

}
