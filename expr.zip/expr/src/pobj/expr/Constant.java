/**
 * 
 */
package pobj.expr;

/**
 * @author Mohamed M. THIAM
 *
 */
public class Constant implements Expression {
	private int value;

	/**
	 * Création d'une constante avec la valeur 0
	 */
	public Constant(){
		value = 0;
	}
	
	/**
	 * Création d'une constante avec la valeur de value
	 * @param value
	 */
	public Constant(int value) {
		this.value = value;
	}

	/**
	 * 
	 * @return la valeur de la constante
	 */
	public int getValue() {
		return value;
	}

	
	/**
	 * Affiche uniquement la valeur de constante
	 */
	@Override
	public String toString() {
		return ""+value;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Constant other = (Constant) obj;
		if (value != other.value) {
			return false;
		}
		return true;
	}

/*	public int eval() {
		return getLeft().eval() + getRight().eval();
	}
*/

	@Override
	public <T> T accept(IVisitor<T> visitor) {
		return visitor.visit(this);
	}



	
	
}
