/**
 * 
 */
package pobj.multiset.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

import pobj.multiset.HashMultiSet;
import pobj.multiset.MultiSet;

/**
 * @author Mohamed M. THIAM
 *
 */
public class HashMultiSetTest2<T> {
	
	@Test
	public void testAdd1()throws IllegalArgumentException{
		MultiSet<String> ms = new HashMultiSet<>();
		ms.add("a");
		ms.add("a", 5);
		assertEquals(ms.count("a"), 6);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testAdd2() throws IllegalArgumentException{
		MultiSet<String> ms = new HashMultiSet<>();
		ms.add("a");
		ms.add("a", -1);
	}
	
	@Test 
	public void testRemove() {
		MultiSet<String> ms = new HashMultiSet<>();
		String a = "a";
		ms.add(a);
		ms.remove(a);
		
		assertEquals(0, ms.count(a));
		
		ms.add(a, 3);
		
		assertEquals(true, ms.remove(a, 3));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testAdd_Remove_Count() {
		MultiSet<String> ms = new HashMultiSet<>();
		ms.remove("e", -1);
		
		assertFalse(ms.remove("e"));
		
		ms.add("e");
		
		assertEquals(false, ms.remove("e", 0));
		
		String r = "r";
		ms.add(r, 18);
		ms.remove(r, 18);
		
		assertEquals(0, ms.count(r));
		
		String o = "o";
		assertEquals(0, ms.count(o));
	}
	
	@Test
	public void testSize() {
		MultiSet<String> ms = new HashMultiSet<>();
		
		assertEquals(0, ms.size());
		
		String a = "a";
		String b = "b";
		ms.add(a, 7);
		ms.add(b, 5);
		
		assertEquals(12, ms.size());
		
		ms.remove(a, 2);
		ms.add(a);
		ms.remove(b, 5);
		
		assertEquals(6, ms.size());
		
		ms.clear();
		
		assertEquals(0, ms.size());
	}
	
	@Test
	public void testToString() {
		MultiSet<String> ms = new HashMultiSet<>();
		ms.add("a", 7);
		ms.add("b", 5);
		
		assertEquals("[a : 7;\nb : 5]" , ms.toString());
	}
	
	@Test
	public void testClear() {
		MultiSet<String> ms = new HashMultiSet<>();
		
		ms.add("a", 7);
		ms.add("b", 5);
		ms.add("f", 7);
		ms.add("t", 5);
		ms.add("e", 7);
		ms.add("w", 5);
		
		assertEquals((3*(7+5)), ms.size());
		
		ms.clear();
		
		assertEquals(0, ms.size());
	}
}








