/**
 * 
 */
package pobj.multiset.test;

import pobj.multiset.InvalidMultiSetFormat;
import pobj.multiset.MultiSet;
import pobj.multiset.MultiSetParser;

/**
 * @author Mohamed M. THIAM
 *
 */
public class MultiSetParserTest {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		MultiSet<String> ms;
		try {
			ms = MultiSetParser.parse("data/data2.txt");
		} catch (InvalidMultiSetFormat e) {
			e.printStackTrace();
		}
		
	}

}
