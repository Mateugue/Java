package pobj.multiset;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;



public class NaiveMultiSet<T>  extends AbstractCollection<T> implements MultiSet<T>, Iterable<T>, Collection<T>{
	private List<T> list;
	
	public NaiveMultiSet() {
		list = new ArrayList<>();
	}
	
	public NaiveMultiSet(Collection<T> col) {
		list = new ArrayList<>();
		list.addAll(col);
	}
	
	@Override
	public boolean add(T e, int count) {
		for(int i = 0; i < count; i++) {
			list.add(e);
		}
		assert isConsistent();
		return true;
	}

	@Override
	public boolean add(T e) {
		return add(e, 1);
	}

	@Override
	public boolean remove(Object e) {
		return remove(e, 1);
	}

	@Override
	public boolean remove(Object e, int count) {
		if(count == 0)
			return false;
		for(int i = 0; i < count; i++) {
			list.remove(e);			
		}
		assert isConsistent();
		return true;
		
	}

	@Override
	public int count(T o) {
		int nb = 0;
		for(T e : list) {
			if(e.equals(o)) {
				nb++;				
			}
		}
		return nb;
	}

	@Override
	public void clear() {
		list.clear();
	}

	@Override
	public int size() {
		return list.size();
	}
	
	@Override
	public Iterator<T> iterator() {
		return list.iterator();
	}

	@Override
	public List<T> elements() {
		List<T> elementsMultiSet = new ArrayList<>();
		for(T e : list) {
			if(!elementsMultiSet.contains(e))
				elementsMultiSet.add(e);
		}
		return elementsMultiSet;
	}

	@Override
	public List<T> allElements() {
		return list;
	}
	
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < list.size(); i++) {
			sb.append(list.get(i) + "\n");
		}
		return sb.toString();
	}

	@Override
	public boolean isConsistent() {
		return list.size() == size();
	}
}