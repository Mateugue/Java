/**
 * 
 */
package pobj.multiset;

import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.List;

/**
 * @author Mohamed M. THIAM
 *
 */
public class MultiSetDecorator<T> extends AbstractCollection<T> implements MultiSet<T> {
	private MultiSet<T> decorated;
	
	public MultiSetDecorator(MultiSet<T> decorated) {
		this.decorated = decorated;
	}
	
	@Override
	public boolean add(T e, int count) {
		boolean b = decorated.add(e, count);
		boolean c = decorated.isConsistent();
		if(!c) {
			throw new InternalError("Erreur interne lors d'un ajout");
		}
		return b;
	}

	@Override
	public boolean add(T e) {
		return decorated.add(e);
	}

	@Override
	public boolean remove(Object e) {
		return decorated.remove(e);
	}

	@Override
	public boolean remove(Object e, int count) {
		boolean b = decorated.remove(e, count);
		boolean c = decorated.isConsistent();
		if(!c) {
			throw new InternalError("Erreur interne lors d'une suppression");
		}
		return b;
	}

	@Override
	public int count(T o) {
		return decorated.count(o);
	}

	@Override
	public void clear() {
		decorated.clear();
	}

	@Override
	public int size() {
		return decorated.size();
	}

	@Override
	public List<T> elements() {
		return decorated.elements();
	}

	@Override
	public List<T> allElements() {
		return decorated.allElements();
	}

	@Override
	public Iterator<T> iterator() {
		return decorated.iterator();
	}
	
	
	@Override
	public String toString() {
		return decorated.toString();
	}

	@Override
	public boolean isConsistent() {
		return decorated.isConsistent();
	}

}
