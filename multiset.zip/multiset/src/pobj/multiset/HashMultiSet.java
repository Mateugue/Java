/**
 * 
 */
package pobj.multiset;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

/**
 * @author Mohamed M. THIAM
 *
 */
public class HashMultiSet<T> extends AbstractCollection<T> implements MultiSet<T> {
	private HashMap<T, Integer> hashMap;
	
	public HashMultiSet(Collection<T> coll) {
		hashMap = new HashMap<>();
		for(T e : coll) {
			add(e);
		}
	}
	
	public HashMultiSet() {
		hashMap = new HashMap<>();
	}

	@Override
	public boolean add(T e, int count) {
		if(count < 0) {
			throw new IllegalArgumentException("Ajout d'un nombre négatif d'éléments"); 
		}
		if(count == 0) {
			return false;
		}
		Integer nbE = hashMap.get(e);
		if (nbE == null) {
			hashMap.put(e,count);
			assert isConsistent();
			return true;
		}
		hashMap.replace(e, nbE + count);
		assert isConsistent();
		return true;
	}

	@Override
	public boolean add(T e) {
		return add(e, 1);
	}

	@Override
	public boolean remove(Object e) {
		return remove(e, 1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object e, int count) {
		if(count < 0) {
			throw new IllegalArgumentException("Suppression d'un nombre négatif d'éléments"); 
		}
		if (count == 0 || (!hashMap.containsKey(e)))
			return false;
		
		Integer nb = hashMap.get(e);
		if (nb == null || nb.intValue() == 0) {
			return false;
		}
		if (count >= nb) {			
			hashMap.remove(e,nb);
		}
		else if( count < nb) {
			hashMap.replace((T)e, nb-count);
		}
		assert isConsistent();
		return true;
	}

	@Override
	public int count(T o) {
		if(!hashMap.containsKey(o)) {
			return 0;
		}
		return hashMap.get(o).intValue();
	}

	@Override
	public void clear() {
		hashMap.clear();
	}

	@Override
	public int size() {
		int cpt = 0;
		for(T e : hashMap.keySet()) {
			cpt += hashMap.get(e).intValue();
		}
		return cpt;
	}
	
	/**
	 * Classe interne qui permettra le parcours du hashMap 
	 * @author Mohamed M. THIAM
	 *
	 */
	private class HashMultiSetIterator implements Iterator<T> {
		private T key = null;
		private int nbKey = 0;
		private Iterator<Entry<T, Integer>> it = hashMap.entrySet().iterator();
		
		@Override
		public boolean hasNext() {
			return !(!it.hasNext() && nbKey == 0);
		}

		@Override
		public T next() {
			if(!it.hasNext() && nbKey == 0) {
				throw new NoSuchElementException();
			}
			Entry<T, Integer> temp = null;
			if(nbKey == 0) {
				if (it.hasNext()) {
					temp = it.next();
					key = temp.getKey();
					nbKey = temp.getValue();
				}
			}
			nbKey--;
			return key;
		}

	}
	
	public Iterator<T> iterator(){
		return new HashMultiSetIterator();
	}

	@Override
	public List<T> elements() {
		List<T> list = new ArrayList<>();
		list.addAll(hashMap.keySet());
		
		Iterator<T> tmp = iterator();		
		for(int i = 0; i < hashMap.size(); i++) {
			T elt = tmp.next();
			if(!(list.contains(elt))) {
				list.add(elt);
			}
		}
		return list;
	}

	@Override
	public List<T> allElements() {
		List<T> list = new ArrayList<>();
		list.addAll(hashMap.keySet());
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals (Object o) {
		if(o == this) 
			return true;
		if (!(o instanceof HashMultiSet)) {
			return false;			
		}
		HashMultiSet<T> m = (HashMultiSet<T>) o;
		if (this.hashMap.equals(m.hashMap)) {
			return true;			
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		Integer val;
		int n = hashMap.keySet().size();
		for(T key : hashMap.keySet()) {
			sb.append(key + ":");
			n--;
			val = Integer.valueOf(count(key));
			sb.append(val);
			if(n != 0) {
				sb.append(";\n");
			}
		}
		sb.append("]");
		return sb.toString();
	}
	
	/**
	 * Permet d'avoir à tout moment un état interne cohérent
	 * @return un booléen qui indique lors de son invocation que l'état interne est toujours cohérent
	 */
	public boolean isConsistent() {
		Integer val;
		int size = 0;
		for(T key : hashMap.keySet()) {
			val = hashMap.get(key).intValue();
			if(val <= 0) {
				return false;
			}
			size += val;
		}
		if(size == size()) {
			return true;			
		}
		return false;
	}
	
}
