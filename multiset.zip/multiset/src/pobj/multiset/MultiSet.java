package pobj.multiset;

import java.util.Collection;
import java.util.List;

public interface MultiSet<T> extends Iterable<T>, Collection<T>{
	/**
	 * ajoute count occurrences de l’objet e
	 * @param e objet qu'on veut ajouter
	 * @param count le nombre de fois qu'on veut ajouter e dans le multi ensemble
	 * @throw IllegalArgumentException
	 * @return un booléen pour indiquer si la modification a été faite
	 */
	public boolean add(T e, int count);
	
	/**
	 * ajoute 1 occurrence de l’objet e
	 * @param e objet qu'on veut ajouter
	 * @return un booléen pour indiquer si la modification a été faite
	 */
	public boolean add(T e);
	
	/**
	 * enlève 1 occurrence de l’objet e
	 * @param e objet qu'on veut retirer
	 * @return un booléen pour indiquer si la modification a été faite
	 */
	public boolean remove(Object e);
	
	/**
	 * enlève count occurrences de l’objet e
	 * @param e objet qu'on veut retirer
	 * @param count le nombre de fois qu'on veut retirer e du multi ensemble
	 * @throw IllegalArgumentException
	 * @return un booléen pour indiquer si la modification a été faite
	 */
	public boolean remove(Object e, int count);
	
	/**
	 * 
	 * @param o l'objet dont on cherche à connaitre son nombre d'occurrences
	 * @return le nombre d'occurrences de l'objet dans le multi ensemble
	 */
	public int count(T o);
	
	/**
	 * vide le multi-ensemble
	 */
	public void clear();	
	
	/**
	 * indique la taille du multi ensemble
	 * @return la somme des nombres d'occurrences de chaque élément du multi ensemble
	 */
	public int size();
	
	/**
	 * Permet de récupérer la liste des mots en ne mettant pas les doublons. Chaque mot qui s'y trouve 
	 * 	aura une unique occurrence 
	 * @return La liste composée des éléments du MultiSet
	 */
	public List<T> elements();
	
	/**
	 * Permet de récupérer la liste de tous les mots, doublons compirs. 
	 * @return La liste composée des éléments du MultiSet
	 */
	public List<T> allElements();
	
	/**
	 * Permet d'avoir à tout moment un état interne cohérent
	 * @return un booléen qui indique lors de son invocation que l'état interne est toujours cohérent
	 */
	public boolean isConsistent();
	
}
