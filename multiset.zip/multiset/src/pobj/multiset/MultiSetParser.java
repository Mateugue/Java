/**
 * 
 */
package pobj.multiset;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Mohamed M. THIAM
 *
 */
public class MultiSetParser {
	@SuppressWarnings("resource")
	public static MultiSet<String> parse(String filename) throws InvalidMultiSetFormat{
		MultiSet<String> ms = new HashMultiSet<>();
		BufferedReader br;
		String line;
		String [] contenuLigne; 
		int numL = 1;
		int count;
		try {
			br = new BufferedReader(new FileReader(filename));
			
			while ((line = br.readLine()) != null) {
				if(!(line.contains(":"))) {
					throw new InvalidMultiSetFormat("La ligne " + numL + " ne contient pas de séparateur");
				}
				contenuLigne = line.split(":");
				count = Integer.decode(contenuLigne[1]);
				if(count < 0) {
					throw new InvalidMultiSetFormat("Un nombre négatif d'éléments à la ligne " + numL);
				}
				ms.add(contenuLigne[0], count);
				numL++;
			}
			
			br.close();
			System.out.println(ms.toString());
			
		} catch (FileNotFoundException e) {
			throw new InvalidMultiSetFormat("Fichier non trouvé ");
		} catch (IOException e) {
			throw new InvalidMultiSetFormat("Erreur d'entrées-sorties ");
		} catch (NumberFormatException e) {
			throw new InvalidMultiSetFormat("Ce qui devait être le nombre d'occurences du mot n'est pas un entier à la ligne " + numL);
		}
		return ms;
	}

	
}
