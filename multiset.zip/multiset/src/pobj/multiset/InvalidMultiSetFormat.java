/**
 * 
 */
package pobj.multiset;

/**
 * @author Mohamed M. THIAM
 *
 */

public class InvalidMultiSetFormat extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidMultiSetFormat(String msg) {
		super("InvalidMultiSetFormat : " + msg);
	}
	
	public InvalidMultiSetFormat(String msg, Throwable cause) {
		super("InvalidMultiSetFormat : " + msg);
	}

}
