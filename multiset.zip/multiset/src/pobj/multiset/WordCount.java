/**
 * 
 */
package pobj.multiset;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.Comparator;
import java.util.List;

import pobj.util.Chrono;

/**
 * @author Mohamed M. THIAM
 *
 */
public class WordCount {
	
	
	public static void wordCount(MultiSet<String> ms) throws IOException {
		String file = "data/WarAndPeace.txt";
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line;
		while ((line = br.readLine()) != null) {
			for (String word : line.split("\\P{L}+")) {
				if (word.equals("")) {
					continue; // ignore les mots vides
				}else {
					ms.add(word);
				}
			}
		}
		br.close();
		class Compare<T> implements Comparator<T>{
			MultiSet<T> multiSet;
			
			public Compare(MultiSet<T> ms) {
				multiSet = ms;
			}
			@Override
			public int compare(T arg0, T arg1) {
				return Integer.compare(multiSet.count(arg1), multiSet.count(arg0)); 
			}
			
		}
		List<String> allElts = ms.allElements();
		Comparator<String> comp = new Compare<String>(ms);
		allElts.sort(comp); // trie la liste elements
/*		String mot;
		Integer count;
		System.out.println("Mot  :  Count ");
		for(int i=0; i < 10; i++) { // pour les 10 premières entrées de la liste elements
			mot = allElts.get(i); //recupération du ième mot
			count = ms.count(mot); //nombre du mot
			System.out.println(mot+" : "+count);
		}
*/		
	}
	
	public static void main(String args[]) {
//		System.out.println("Pour HashMultiSet : ");
		System.out.println("Pour HashMultiSetDecorator : ");
		HashMultiSet<String> hashMultiSet = new HashMultiSet<String>();
		MultiSetDecorator<String> hashDeco = new MultiSetDecorator<String>(hashMultiSet);
		Chrono ch1 = new Chrono();
		try {
//			wordCount(hashMultiSet);
			wordCount(hashDeco);
			System.out.println(hashDeco.toString());
		} catch (IOException e) {
			System.out.println("Ne devrait pas arriver, mais c'est lié au wordCount de Hash " + e);
		}
		System.out.println("");
		ch1.stop();
		
//		System.out.println("\nPour NaiveMultiSet: ");
		System.out.println("\nPour NaiveMultiSetDecorator : ");
		NaiveMultiSet<String> naiveMultiSet = new NaiveMultiSet<String>();
		MultiSetDecorator<String> naiveDeco = new MultiSetDecorator<String>(naiveMultiSet);
		Chrono ch2 = new Chrono();
/*		try {
//			wordCount(naiveMultiSet);
			wordCount(naiveDeco);
			System.out.println(naiveDeco.toString());
		} catch (IOException e) {
			System.out.println("Ne devrait pas arriver, mais c'est lié au wordCount de Naive " + e);
		}
*/
		System.out.println("");
		ch2.stop();
	}
}
